# Diagramas UML de Leadify

Cuatro vistas del sistema, dibujadas a partir del código y de la base de datos
reales del repositorio (no de un diseño aparte). Cada diagrama tiene su imagen
(`.png`) y su fuente editable en [PlantUML](https://plantuml.com) (`.puml`).

| # | Diagrama | Imagen | Fuente |
|---|---|---|---|
| 1 | Clases | [01-diagrama-de-clases.png](01-diagrama-de-clases.png) | [.puml](01-diagrama-de-clases.puml) |
| 2 | Procesos (carriles) | [02-diagrama-de-procesos.png](02-diagrama-de-procesos.png) | [.puml](02-diagrama-de-procesos.puml) |
| 3 | Secuencia | [03-diagrama-de-secuencia.png](03-diagrama-de-secuencia.png) | [.puml](03-diagrama-de-secuencia.puml) |
| 4 | Modelo relacional | [04-modelo-relacional.png](04-modelo-relacional.png) | [.puml](04-modelo-relacional.puml) |

## 1. Diagrama de clases

![Diagrama de clases](01-diagrama-de-clases.png)

El código de Leadify casi no usa clases: el motor de Python es de funciones
y el formulario son módulos de JavaScript. Por eso este diagrama es de
**diseño del dominio**: cada clase corresponde a un concepto real del sistema y
al archivo donde vive.

| Clase | De dónde sale |
|---|---|
| `Lead`, `Consulta`, `Interes` | Tablas `leads`, `consultas` e `intereses` ([`Database/esquema/`](../../Database/esquema/)). Sus métodos son las 4 funciones PL/pgSQL. |
| `FormularioUsuario` | Modelo Pydantic de [`Demo/backend/api/app.py`](../../Demo/backend/api/app.py). |
| `MotorRecomendacion`, `Recomendacion`, `Proyecto` | Pipeline de [`Demo/backend/Model/`](../../Demo/backend/Model/) (`primer_filtro`, `modelo`, `Cota_minimaBG`, `post_arreglos`) y su `respuesta_json`. |
| `Constructora`, `TipoVivienda` | Catálogo de 96 proyectos de 4 constructoras; VIS / No VIS. |
| `CalificacionLead`, `EstadoCalificacion` | [`js/qualification.js`](../../Demo/frontend/public/experiencia/js/qualification.js): "Listo para asesor" o "En maduración" (umbral 60). |
| `SolicitudLlamada`, `ApartamentoLlamada` | Modelos Pydantic de `POST /api/llamar`. |
| `ServicioLlamadas`, `ResultadoLlamada` | Endpoints de Dapta (`/api/llamar`, `/webhooks/dapta/resultado`, `/api/llamar/resultado`). |

## 2. Diagrama de procesos

![Diagrama de procesos](02-diagrama-de-procesos.png)

El recorrido completo, repartido en cuatro carriles: **Comprador**, **Sistema
Leadify**, **Manuela (Dapta)** y **Asesor comercial**. Muestra las tres
decisiones importantes: si el comprador ya tiene una consulta guardada, si el
motor respondió (si no, hay catálogo aproximado) y si en la llamada se agendó
cita.

## 3. Diagrama de secuencia

![Diagrama de secuencia](03-diagrama-de-secuencia.png)

Los mensajes reales entre el formulario, la API FastAPI, el motor, Supabase y
Dapta, en cuatro fases: identificarse, recomendar, elegir proyecto y pedir la
llamada, y registrar el resultado. Incluye la regla de negocio de la base de
datos: pedir la llamada **no** cuenta como intención de compra; solo cuenta si
Dapta devuelve una `fecha_de_seguimiento`.

## 4. Modelo relacional

![Modelo relacional](04-modelo-relacional.png)

Las tres tablas de Supabase tal como están en
[`01_tablas.sql`](../../Database/esquema/01_tablas.sql). El catálogo de
proyectos no está en la base de datos: vive en archivos JSON del motor.

## Cómo regenerar las imágenes

Se necesita Java y el [jar de PlantUML](https://github.com/plantuml/plantuml/releases):

```bash
cd Docs/Diagramas
java -jar plantuml.jar -tpng -charset UTF-8 -Sdpi=110 *.puml
```

También se pueden pegar los `.puml` en <https://www.plantuml.com/plantuml> para
verlos y editarlos sin instalar nada.
